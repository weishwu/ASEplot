library(ggplot2)
library(Gviz)
library(GenomicRanges)
library(biomaRt)
library(ggridges)
library(dplyr)
library(tidyverse)
library(pheatmap)
library(ggrepel)
library(ASEplot)

#setwd('~/Downloads')
#ase_rds = readRDS('~/Downloads/ase_data.20samples.Rds')

data('ase_data.test')
ase_df = ase_data$ase_df
exons = ase_data$union_exons_per_gene

# Select only the lines with unique genes
ase_df_uniqGene = ase_df %>% filter(! grepl(';', genes_exonic))

# Filter data
ase_selc = ase_df_uniqGene %>% filter( 
    (totalCount >= 10) & 
    (!is.na(exons_merged)) & 
    (!grepl(';', exons_merged)) &
    (nonAltFreq_perRNAid < 0.05)) %>% dplyr::select(
    RNAid,variantID,contig,position,strand,refCount,altCount,
    totalCount,rawASE,exons_merged,gene_type_exonic,
    PatAllele,MatAllele,PatDepth,MatDepth,PatFreq,genes_exonic)


contam = unique(ase_df_uniqGene %>% select(RNAid, nonAltFreq_perRNAid, nonRefFreq_perRNAid))
ggplot(contam, aes(x=nonAltFreq_perRNAid, y=nonRefFreq_perRNAid)) + 
   geom_point(alpha=0.2, size=3) + 
   theme_bw() + 
   geom_vline(xintercept = 0.05, color='red', linetype='dashed',alpha=0.6) + 
   geom_text_repel(data = contam %>% filter(nonAltFreq_perRNAid > 0.05), aes(label = RNAid)) + 
   theme(plot.margin = unit(c(1,1,1,1), 'cm'))
ggsave('contam.png', width = 3.5, height = 3.2)
gene_contam = unique(ase_df_uniqGene %>% 
   filter(! is.na(homRef_nonRefFreq_atMatAlt_mean_perGene_perRNAid)) %>% 
   select(RNAid, genes_exonic,homRef_nonRefFreq_atMatAlt_mean_perGene_perRNAid))

gene_contam = gene_contam %>% 
   pivot_wider(id_cols = genes_exonic, 
               names_from = RNAid, 
               values_from = homRef_nonRefFreq_atMatAlt_mean_perGene_perRNAid) %>% 
   column_to_rownames('genes_exonic')

pheatmap(gene_contam[1:40,], 
         cluster_cols = FALSE, 
         cluster_rows = FALSE, 
         na_col ='white',color = colorRampPalette(c("skyblue", "red"))(500),
         breaks = seq(0, 0.05, 0.05/500))
pdf(file='contam_per_gene.pdf', width = 8, height = 6)
pheatmap(gene_contam[1:40,], 
         cluster_cols = FALSE, 
         cluster_rows = FALSE, 
         na_col ='white',color = colorRampPalette(c("skyblue", "red"))(500),
         breaks = seq(0, 0.05, 0.05/500))
dev.off()


snp_location(ase_selc, exons, 'RHOBTB3', 'split', 'hg38', '123884')
pdf(file = 'snp_location.pdf', width = 8, height = 6)
snp_location(ase_selc, exons, 'RHOBTB3', 'split', 'hg38', '123884')
dev.off()

pdf(file = 'snp_location_collapsed.pdf', width = 8, height = 6)
snp_location(ase_selc, exons, 'RHOBTB3', 'collapse', 'hg38', '123884')
dev.off()

gene_poe_histogram_plot = gene_poe_histogram(ase_selc, 'RHOBTB3', 'pat-freq', sample_name = '123884') + theme(text = element_text(size=15))
#ggsave('histogram.png', width = 8, height = 6)

gene_poe_ridge_plot = gene_poe_ridge(ase_selc, c('MEG8', 'CYB5R2', 'IGF2', 'RHOBTB3', 'THEGL', 'GNAS', 'PEG3'), 'pat-freq')
#ggsave('ridges.png', width = 8, height = 6)
plot_grid(gene_poe_histogram_plot, gene_poe_ridge_plot, align='hv', labels=c('A','B'), nrow=1)
ggsave('figure4.png', width = 12, height = 4)

snp_gene_ase_heatmap(ase_selc, exons, 'RHOBTB3', 'pat-freq')
ggsave('heatmap.png', width = 8, height = 6)

snp_gene_ase_boxplot_plot = snp_gene_ase_boxplot(ase_selc, 'RHOBTB3', 'pat-freq') +
theme(axis.text.x = element_text(size = 15),axis.text.y = element_text(size = 15)) +
theme(axis.title.y = element_text(size=25)) +
theme(plot.title = element_text(size = 25)) 
#ggsave('boxplot.png', width = 8, height = 6)

snp_gene_ase_scatter_plot = snp_gene_ase_scatter(ase_selc, exons, 'RHOBTB3','pat-freq','123884') +
theme(text = element_text(size = 25)) +
theme(plot.title = element_text(size = 20)) +
theme(axis.title.x = element_text(vjust = 15))
#ggsave('scatter.png', width = 10, height = 4)
plot_grid(snp_gene_ase_boxplot_plot, snp_gene_ase_scatter_plot, nrow=2, align='hv', labels=c('A','B'), label_size = 25)
ggsave('figure5.png', width = 13, height = 13)

