library(ggplot2)
library(Gviz)
library(GenomicRanges)
library(biomaRt)
library(ggridges)
library(dplyr)
library(tidyverse)
library(pheatmap)
library(ggrepel)
library(ASEplot)

#setwd('~/Downloads')
#ase_rds = readRDS('~/Downloads/ase_data.20samples.Rds')

data('ase_data.test')
ase_df = ase_data$ase_df
exons = ase_data$union_exons_per_gene

# Select only the lines with unique genes
ase_df_uniqGene = ase_df %>% filter(! grepl(';', genes_exonic))

# Filter data
ase_selc = ase_df_uniqGene %>% filter( 
    (totalCount >= 10) & 
    (!is.na(exons_merged)) & 
    (!grepl(';', exons_merged)) &
    (nonAltFreq_perRNAid < 0.05)) %>% dplyr::select(
    RNAid,variantID,contig,position,strand,refCount,altCount,
    totalCount,rawASE,exons_merged,gene_type_exonic,
    PatAllele,MatAllele,PatDepth,MatDepth,PatFreq,genes_exonic)


contam = unique(ase_df_uniqGene %>% select(RNAid, nonAltFreq_perRNAid, nonRefFreq_perRNAid))
ggplot(contam, aes(x=nonAltFreq_perRNAid, y=nonRefFreq_perRNAid)) + 
   geom_point(alpha=0.6) + 
   theme_bw() + 
   geom_vline(xintercept = 0.05, color='red', linetype='dashed',alpha=0.6) + 
   geom_text_repel(data = contam %>% filter(nonAltFreq_perRNAid > 0.05), aes(label = RNAid))
ggsave('contam.png', width = 8, height = 6)
gene_contam = unique(ase_df_uniqGene %>% 
   filter(! is.na(homRef_nonRefFreq_atMatAlt_mean_perGene_perRNAid)) %>% 
   select(RNAid, genes_exonic,homRef_nonRefFreq_atMatAlt_mean_perGene_perRNAid))

gene_contam = gene_contam %>% 
   pivot_wider(id_cols = genes_exonic, 
               names_from = RNAid, 
               values_from = homRef_nonRefFreq_atMatAlt_mean_perGene_perRNAid) %>% 
   column_to_rownames('genes_exonic')

pheatmap(gene_contam[1:40,], 
         cluster_cols = FALSE, 
         cluster_rows = FALSE, 
         na_col ='white',color = colorRampPalette(c("skyblue", "red"))(500),
         breaks = seq(0, 0.05, 0.05/500))
pdf(file='contam_per_gene.pdf', width = 8, height = 6)
pheatmap(gene_contam[1:40,], 
         cluster_cols = FALSE, 
         cluster_rows = FALSE, 
         na_col ='white',color = colorRampPalette(c("skyblue", "red"))(500),
         breaks = seq(0, 0.05, 0.05/500))
dev.off()


snp_location(ase_selc, exons, 'RHOBTB3', 'split', 'hg38', '123884')
pdf(file = 'snp_location.pdf', width = 8, height = 6)
snp_location(ase_selc, exons, 'RHOBTB3', 'split', 'hg38', '123884')
dev.off()

pdf(file = 'snp_location_collapsed.pdf', width = 8, height = 6)
snp_location(ase_selc, exons, 'RHOBTB3', 'collapse', 'hg38', '123884')
dev.off()

gene_poe_histogram(ase_selc, 'RHOBTB3', 'pat-freq', sample_name = '123884')
ggsave('histogram.png', width = 8, height = 6)

gene_poe_ridge(ase_selc, c('MEG8', 'CYB5R2', 'IGF2', 'RHOBTB3', 'THEGL', 'GNAS', 'PEG3'), 'pat-freq')
ggsave('ridges.png', width = 8, height = 6)

snp_gene_ase_heatmap(ase_selc, exons, 'RHOBTB3', 'pat-freq')
ggsave('heatmap.png', width = 8, height = 6)

snp_gene_ase_boxplot(ase_selc, 'RHOBTB3', 'pat-freq') 
ggsave('boxplot.png', width = 8, height = 6)

snp_gene_ase_scatter(ase_selc, exons, 'RHOBTB3','pat-freq','123884')
ggsave('scatter.png', width = 10, height = 4)

